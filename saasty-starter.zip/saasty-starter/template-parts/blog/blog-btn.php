<?php

/**
 * Template part for displaying post btn
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package saasty_starter
 */

$saasty_starter_blog_btn = get_theme_mod( 'saasty_starter_blog_btn', 'Read More' );
$saasty_starter_blog_btn_switch = get_theme_mod( 'saasty_starter_blog_btn_switch', true );

?>

<?php if ( !empty( $saasty_starter_blog_btn_switch ) ): ?>
<a class="it-btn-green mt-15" href="<?php the_permalink();?>"><span><?php print esc_html( $saasty_starter_blog_btn );?></span></a>
<?php endif;?>