<?php

/**
 * saasty_starter customizer
 *
 * @package saasty_starter
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}


add_action(
    'init',
    function () {

        if (class_exists('kirki')) {

            /**
             * Added Panels & Sections
             */

            //Add panel
            new \Kirki\Panel(
                'saasty_starter_customizer',
                [
                    'priority'    => 10,
                    'title'       => esc_html__('Saasty Customizer', 'saasty-starter'),
                ]
            );


               //Add panel
            new \Kirki\Panel(
                'saasty_starter_front_page',
                [
                    'priority'    => 10,
                    'title'       => esc_html__('Front Page', 'saasty-starter'),
                ]
            );


             /**
             * Front Page
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'saasty_starter_hero_section',
                [
                    'title'       => esc_html__('Hero Section', 'saasty-starter'),
                    'description' => esc_html__('', 'saasty-starter'),
                    'panel'       => 'saasty_starter_front_page',
                    'priority'    => 10,
                ]
            );


            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'saasty_starter_hero_title',
                    'label'       => esc_html__( 'Title', 'saasty-starter' ),
                    'section'     => 'saasty_starter_hero_section',
                    'default'     => saasty_starter_kses('Successful Businesses Begin with Organized Finances.', 'saasty-starter' ),
                ]
            );

            // sub title

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'saasty_starter_hero_subtitle',
                    'label'       => esc_html__( 'Sub Title', 'saasty-starter' ),
                    'section'     => 'saasty_starter_hero_section',
                    'default'     => saasty_starter_kses('Welcome Our SaasTech', 'saasty-starter' ),
                ]
            );

            // description

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'saasty_starter_hero_desc',
                    'label'       => esc_html__( 'Description', 'saasty-starter' ),
                    'section'     => 'saasty_starter_hero_section',
                    'default'     => saasty_starter_kses('Efficient planning, seamless collaboration, and top-notch <br> data protection – all in one place.', 'saasty-starter' ),
                ]
            );

            // button text

            new \Kirki\Field\Text(
                [
                    'settings'    => 'saasty_starter_hero_btn_text',
                    'label'       => esc_html__( 'Button Text', 'saasty-starter' ),
                    'section'     => 'saasty_starter_hero_section',
                    'default'     => saasty_starter_kses( 'Get Started', 'saasty-starter' ),
                ]
            );

            // button link

            new \Kirki\Field\Text(
                [
                    'settings'    => 'saasty_starter_hero_btn_link',
                    'label'       => esc_html__( 'Button Link', 'saasty-starter' ),
                    'section'     => 'saasty_starter_hero_section',
                    'default'     => saasty_starter_kses( '#', 'saasty-starter' ),
                ]
            );


            // thumbnail

            new \Kirki\Field\Image(
                [
                    'settings'    => 'saasty_starter_hero_image',
                    'label'       => esc_html__( 'Hero Image', 'saasty-starter' ),
                    'section'     => 'saasty_starter_hero_section',
                    'default'     => get_template_directory_uri() . '/assets/img/hero/hero-1.png',
                ]
            );

            // Shape

            new \Kirki\Field\Image(
                [
                    'settings'    => 'saasty_starter_hero_shape',
                    'label'       => esc_html__( 'Hero Shape', 'saasty-starter' ),
                    'section'     => 'saasty_starter_hero_section',
                    'default'     => get_template_directory_uri() . '/assets/img/hero/shape-1.png',
                ]
            );

            // shape 2

            new \Kirki\Field\Image(
                [
                    'settings'    => 'saasty_starter_hero_shape_2',
                    'label'       => esc_html__( 'Hero Shape 2', 'saasty-starter' ),
                    'section'     => 'saasty_starter_hero_section',
                    'default'     => get_template_directory_uri() . '/assets/img/hero/shape-2.png',
                ]
            );

            // shape 3

            new \Kirki\Field\Image(
                [
                    'settings'    => 'saasty_starter_hero_shape_3',
                    'label'       => esc_html__( 'Hero Shape 3', 'saasty-starter' ),
                    'section'     => 'saasty_starter_hero_section',
                    'default'     => get_template_directory_uri() . '/assets/img/hero/shape-3.png',
                ]
            );

            /**
             * Feature Section
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'saasty_starter_about_section',
                [
                    'title'       => esc_html__('About Section', 'saasty-starter'),
                    'panel'       => 'saasty_starter_front_page',
                    'priority'    => 10,
                ]
            );


            // about title

            new \Kirki\Field\Text(
                [
                    'settings'    => 'saasty_starter_about_title',
                    'label'       => esc_html__( 'Title', 'saasty-starter' ),
                    'section'     => 'saasty_starter_about_section',
                    'default'     => saasty_starter_kses('About Us', 'saasty-starter' ),
                ]
            );

            // about description

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'saasty_starter_about_desc',
                    'label'       => esc_html__( 'Description', 'saasty-starter' ),
                    'section'     => 'saasty_starter_about_section',
                    'default'     => saasty_starter_kses('Efficient planning, seamless collaboration, and top-notch <br> data protection – all in one place.', 'saasty-starter' ),
                ]
            );

            new \Kirki\Field\Repeater(
                [
                    'settings' => 'saasty_about_faqs',
                    'label'    => esc_html__('About FAQ', 'saasty-starter'),
                    'section'  => 'saasty_starter_about_section',
                    'priority' => 10,
                    'fields'   => [
                        'saasty_about_faq_title'   => [
                            'type'        => 'text',
                            'label'       => esc_html__('Title', 'saasty-starter'),
                            'description' => esc_html__('Title', 'saasty-starter'),
                            'default'     => '',
                        ],
                        'saasty_about_faq_description'   => [
                            'type'        => 'textarea',
                            'label'       => esc_html__('Description', 'saasty-starter'),
                            'description' => esc_html__('Description', 'saasty-starter'),
                            'default'     => '',
                        ],
                    ],
                ]
            );

            // about thumbnail

            new \Kirki\Field\Image(
                [
                    'settings'    => 'saasty_starter_about_image',
                    'label'       => esc_html__( 'About Image', 'saasty-starter' ),
                    'section'     => 'saasty_starter_about_section',
                    'default'     => get_template_directory_uri() . '/assets/img/about/about-1.png',
                ]
            );

            // about thumbnial 2

            new \Kirki\Field\Image(
                [
                    'settings'    => 'saasty_starter_about_image_2',
                    'label'       => esc_html__( 'About Image 2', 'saasty-starter' ),
                    'section'     => 'saasty_starter_about_section',
                    'default'     => get_template_directory_uri() . '/assets/img/about/about-2.png',
                ]
            );

            // about thumbnial 3

            new \Kirki\Field\Image(
                [
                    'settings'    => 'saasty_starter_about_image_3',
                    'label'       => esc_html__( 'About Image 3', 'saasty-starter' ),
                    'section'     => 'saasty_starter_about_section',
                    'default'     => get_template_directory_uri() . '/assets/img/about/about-3.png',
                ]
            );

            // shape

            new \Kirki\Field\Image(
                [
                    'settings'    => 'saasty_starter_about_shape',
                    'label'       => esc_html__( 'About Shape', 'saasty-starter' ),
                    'section'     => 'saasty_starter_about_section',
                    'default'     => get_template_directory_uri() . '/assets/img/about/shape-1.png',
                ]
            );




            /**
             * Feature Section
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'saasty_starter_feature_section',
                [
                    'title'       => esc_html__('Feature Section', 'saasty-starter'),
                    'description' => esc_html__('', 'saasty-starter'),
                    'panel'       => 'saasty_starter_front_page',
                    'priority'    => 10,
                ]
            );


            new \Kirki\Field\Text(
                [
                    'settings'    => 'saasty_starter_feature_title',
                    'label'       => esc_html__( 'Title', 'saasty-starter' ),
                    'section'     => 'saasty_starter_feature_section',
                    'default'     => saasty_starter_kses('Our Features', 'saasty-starter' ),
                ]
            );

            // description

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'saasty_starter_feature_desc',
                    'label'       => esc_html__( 'Description', 'saasty-starter' ),
                    'section'     => 'saasty_starter_feature_section',
                    'default'     => saasty_starter_kses('Efficient planning, seamless collaboration, and top-notch <br> data protection – all in one place.', 'saasty-starter' ),
                ]
            );


            new \Kirki\Field\Repeater(
                [
                    'settings' => 'saasty_starter_feature_list',
                    'label'    => esc_html__('Feature List', 'saasty-starter'),
                    'section'  => 'saasty_starter_feature_section',
                    'priority' => 10,
                    'default'  => [
                        [
                            'saasty_feature_title'   => esc_html__('Title', 'saasty-starter'),
                            'default' => esc_html__('Title', 'saasty-starter'),
                        ],
                        [
                            'saasty_feature_title'   => esc_html__('Title', 'saasty-starter'),
                            'default' => esc_html__('Title', 'saasty-starter'),
                        ],
                    ],
                    'fields'   => [
                        'saasty_feature_title'   => [
                            'type'        => 'text',
                            'label'       => esc_html__('Title', 'saasty-starter'),
                            'description' => esc_html__('Title', 'saasty-starter'),
                            'default'     => '',
                        ],
                        'saasty_feature_description'    => [
                            'type'        => 'textarea',
                            'label'       => esc_html__('Description', 'saasty-starter'),
                            'description' => esc_html__('Description', 'saasty-starter'),
                            'default'     => '',
                        ],
                        
                        'saasty_feature_image'    => [
                            'type'        => 'image',
                            'label'       => esc_html__('Feature Image', 'saasty-starter'),
                            'default'     => '',
                        ],
                        'saasty_feature_url'   => [
                            'type'        => 'text',
                            'label'       => esc_html__('URL', 'saasty-starter'),
                            'description' => esc_html__('#', 'saasty-starter'),
                            'default'     => '',
                        ],


                    ],
                ]
            );


            /**
             * Testimonial Section
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'saasty_starter_testimonial_section',
                [
                    'title'       => esc_html__('Testimonial Section', 'saasty-starter'),
                    'panel'       => 'saasty_starter_front_page',
                    'priority'    => 10,
                ]
            );



            new \Kirki\Field\Text(
                [
                    'settings'    => 'saasty_starter_testi_section_title',
                    'label'       => esc_html__('Title', 'saasty-starter'),
                    'section'     => 'saasty_starter_testimonial_section',
                    'default'     => saasty_starter_kses('What our clients say?', 'saasty-starter'),
                ]
            );

            // description

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'saasty_starter_testi_section_desc',
                    'label'       => esc_html__('Description', 'saasty-starter'),
                    'section'     => 'saasty_starter_testimonial_section',
                    'default'     => saasty_starter_kses('Efficient planning, seamless collaboration, and top-notch <br> data protection – all in one place.', 'saasty-starter'),
                ]
            );



            new \Kirki\Field\Repeater(
                    [
                        'settings' => 'saasty_starter_testimonial_list',
                        'label'    => esc_html__('Testimonial List', 'saasty-starter'),
                        'section'  => 'saasty_starter_testimonial_section',
                        'priority' => 10,
                        'fields'   => [
                            'saasty_testi_title'   => [
                                'type'        => 'text',
                                'label'       => esc_html__('Name', 'saasty-starter'),
                                'description' => esc_html__('Name', 'saasty-starter'),
                                'default'     => '',
                            ],
                            'saasty_testi_desigantion' => [
                                'type'        => 'text',
                                'label'       => esc_html__('Designation', 'saasty-starter'),
                                'description' => esc_html__('Description', 'saasty-starter'),
                                'default'     => '',
                            ],
                            'saasty_testi_description' => [
                                'type'        => 'textarea',
                                'label'       => esc_html__('Description', 'saasty-starter'),
                                'description' => esc_html__('Description', 'saasty-starter'),
                                'default'     => '',
                            ],
                            'saasty_testi_image' => [
                                'type'        => 'image',
                                'label'       => esc_html__('Image', 'saasty-starter'),
                                'description' => esc_html__('Image', 'saasty-starter'),
                                'default'     => '',
                            ],
                        ],
                    ]
                );


            new \Kirki\Field\Image(
                [
                    'settings'    => 'testimonial_thumbnail_image',
                    'label'       => esc_html__('Thumbnail', 'saasty-starter'),
                    'section'     => 'saasty_starter_testimonial_section',
                    'default'     => '',
                ]
            );


            new \Kirki\Field\Image(
                [
                    'settings'    => 'testimonial_thumbnail_shape',
                    'label'       => esc_html__('Shap 1', 'saasty-starter'),
                    'section'     => 'saasty_starter_testimonial_section',
                    'default'     => '',
                ]
            );
            new \Kirki\Field\Image(
                [
                    'settings'    => 'testimonial_thumbnail_shape2',
                    'label'       => esc_html__('Shap 2', 'saasty-starter'),
                    'section'     => 'saasty_starter_testimonial_section',
                    'default'     => '',
                ]
            );

            new \Kirki\Field\Image(
                [
                    'settings'    => 'testimonial_thumbnail_shape3',
                    'label'       => esc_html__('Shap 3', 'saasty-starter'),
                    'section'     => 'saasty_starter_testimonial_section',
                    'default'     => '',
                ]
            );
            new \Kirki\Field\Image(
                [
                    'settings'    => 'testimonial_thumbnail_shape4',
                    'label'       => esc_html__('Shap 4', 'saasty-starter'),
                    'section'     => 'saasty_starter_testimonial_section',
                    'default'     => '',
                ]
            );



            /**
             * Testimonial Section
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'saasty_starter_Blog_section',
                [
                    'title'       => esc_html__('Blog Section', 'saasty-starter'),
                    'panel'       => 'saasty_starter_front_page',
                    'priority'    => 10,
                ]
            );

            // blog Section title

            new \Kirki\Field\Text(
                [
                    'settings'    => 'saasty_starter_blog_section_title',
                    'label'       => esc_html__('Title', 'saasty-starter'),
                    'section'     => 'saasty_starter_Blog_section',
                    'default'     => saasty_starter_kses('Our Blog', 'saasty-starter'),
                ]
            );

            // blog Section description

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'saasty_starter_blog_section_desc',
                    'label'       => esc_html__('Description', 'saasty-starter'),
                    'section'     => 'saasty_starter_Blog_section',
                    'default'     => saasty_starter_kses('Efficient planning, seamless collaboration, and top-notch <br> data protection – all in one place.', 'saasty-starter'),
                ]
            );

            // blog Section button text

            new \Kirki\Field\Text(
                [
                    'settings'    => 'saasty_starter_blog_section_btn_text',
                    'label'       => esc_html__('Button Text', 'saasty-starter'),
                    'section'     => 'saasty_starter_Blog_section',
                    'default'     => saasty_starter_kses('View All', 'saasty-starter'),
                ]
            );

            // blog Section button link

            new \Kirki\Field\Text(
                [
                    'settings'    => 'saasty_starter_blog_section_btn_link',
                    'label'       => esc_html__('Button Link', 'saasty-starter'),
                    'section'     => 'saasty_starter_Blog_section',
                    'default'     => saasty_starter_kses('#', 'saasty-starter'),
                ]
            );





           

       






            /**
             * Customizer Section
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'saasty_starter_general_settngs',
                [
                    'title'       => esc_html__('General Settings', 'saasty-starter'),
                    'description' => esc_html__('', 'saasty-starter'),
                    'panel'       => 'saasty_starter_customizer',
                    'priority'    => 10,
                ]
            );



            new \Kirki\Field\Checkbox_Switch(
                [
                    'settings'    => 'saasty_starter_preloader',
                    'label'       => esc_html__('Preloader On/Off', 'saasty-starter'),
                    'section'     => 'saasty_starter_general_settngs',
                    'default'     => 'off',
                    'choices'     => [
                        'on'  => esc_html__('Enable', 'saasty-starter'),
                        'off' => esc_html__('Disable', 'saasty-starter'),
                    ],
                ]
            );

            new \Kirki\Field\Checkbox_Switch(
                [
                    'settings'    => 'saasty_starter_backtotop',
                    'label'       => esc_html__('Back To Top On/Off', 'saasty-starter'),
                    'section'     => 'saasty_starter_general_settngs',
                    'default'     => 'off',
                    'choices'     => [
                        'on'  => esc_html__('Enable', 'saasty-starter'),
                        'off' => esc_html__('Disable', 'saasty-starter'),
                    ],
                ]
            );










            


      

           

        



            // Header Logo & Style Settings
            new \Kirki\Section(
                'saasty_starter_header_logo',
                [
                    'title'       => esc_html__('Header Settings', 'saasty-starter'),
                    'description' => esc_html__('', 'saasty-starter'),
                    'panel'       => 'saasty_starter_customizer',
                    'priority'    => 10,
                ]
            );

            new \Kirki\Field\Select(
                [
                    'settings'    => 'saasty_starter_header_style',
                    'label'       => esc_html__('Select Header Style', 'saasty-starter'),
                    'section'     => 'saasty_starter_header_logo',
                    'default'     => 'header-style-11',
                    'placeholder' => esc_html__('Choose an option', 'saasty-starter'),
                    'choices'     => [
                        'header-style-11' => esc_html__('Header Style 1', 'saasty-starter'),
                    ],
                ]
            );


            //Header Logo
            new \Kirki\Field\Image(
                [
                    'settings'    => 'header_logo',
                    'label'       => esc_html__('Header Logo', 'saasty-starter'),
                    'description' => esc_html__('Upload Your Logo Here', 'saasty-starter'),
                    'section'     => 'saasty_starter_header_logo',
                    'default'     => get_template_directory_uri() . '/assets/img/logo/logo-1.png',
                ]
            );











            


            //Blog Settings
            new \Kirki\Section(
                'saasty_starter_404_settings',
                [
                    'title'       => esc_html__('404 Settings', 'saasty-starter'),
                    'description' => esc_html__('', 'saasty-starter'),
                    'panel'       => 'saasty_starter_customizer',
                    'priority'    => 10,
                ]
            );

            new \Kirki\Field\Image(
                [
                    'settings'    => '_image_404_setup',
                    'label'       => esc_html__('Upload 404 Image', 'saasty-starter'),
                    'description' => esc_html__('', 'saasty-starter'),
                    'section'     => 'saasty_starter_404_settings',
                    'default'     => get_template_directory_uri() . '/assets/img/error/error.png',
                ]
            );

            new \Kirki\Field\Text(
                [
                    'settings' => 'saasty_starter_error_title',
                    'label'    => esc_html__('Title ', 'saasty-starter'),
                    'section'  => 'saasty_starter_404_settings',
                    'default'  => saasty_starter_kses('Oops! That page can’t be found.', 'saasty-starter'),
                    'priority' => 10,
                ]
            );

            new \Kirki\Field\Text(
                [
                    'settings' => 'saasty_starter_error_desc',
                    'label'    => esc_html__('Description ', 'saasty-starter'),
                    'section'  => 'saasty_starter_404_settings',
                    'default'  => saasty_starter_kses('Oops! The page you are looking for does not exist. It might have <br> been moved or deleted. Please check and try again.', 'saasty-starter'),
                    'priority' => 10,
                ]
            );
            new \Kirki\Field\Text(
                [
                    'settings' => 'saasty_starter_error_link_text',
                    'label'    => esc_html__('Button Text', 'saasty-starter'),
                    'section'  => 'saasty_starter_404_settings',
                    'default'  => esc_html__('Back to Home', 'saasty-starter'),
                    'priority' => 10,
                ]
            );

            
}







    }
);
